<?php include 'components/head.php'; ?>

<?php include 'redirect.php'; ?>

<?php include 'components/navbar.php'; ?>

<body style="height: 100vh" class="grey darken-4">
  <main>
	  	<h2 class="brand-logo center white-text" style="font-size: 40px; font-weight: bolder;">Tips</h2>
	  <br>
	  <div class="container white-text">
	  	<div class="container">
		  	<table class="centered">
	        <thead>
	          <tr>
	              <th>Shortcut</th>
	              <th>Result</th>
	          </tr>
	        </thead>

	        <tbody>
	          <tr>
	            <td>Ctrl + Enter</td>
	            <td>Execute the query</td>
	          </tr>
	          <tr>
	            <td>Shift + Mouse scroll</td>
	            <td>Roll page horizontaly</td>
	          </tr>
	        </tbody>
	      </table>
      </div>
	  </div>
  </main>
</body>
</html>

<?php include 'components/js.php'; ?>
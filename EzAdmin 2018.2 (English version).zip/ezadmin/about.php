<?php include 'components/head.php'; ?>

<?php include 'redirect.php'; ?>

<?php include 'components/navbar.php'; ?>

<body style="height: 100vh" class="grey darken-4">
  <main>
	  	<h2 class="brand-logo center white-text" style="font-size: 40px; font-weight: bolder;">Some stuffs about the project</h2>
	  <br>
	  <div class="container">
	  	<p class="white-text">The project focus on help new developers to develop their new projects using databases. Already exists another better/more functional options, like phpMyAdmin. But in this project, the principal focus it's the use facility, getting a more nice experience for who is using this tool.</p>

	  	<h5 class="white-text">Contact</h5>
	  	<p class="white-text">developer.davi@gmail.com</p>
	  	<h5 class="white-text">Credits</h5>
	  	<p class="white-text">Built with <a href="http://www.materializecss.com">MaterializeCSS</a></p>
	  	<p class="white-text">Syntax highlighting by <a href="https://ace.c9.io/">Ace</a></p>
	  	<p class="white-text">PHP SQL dump by <a href="https://github.com/ifsnop/mysqldump-php">Mysqldump</a></p>
	  	<br><br>
	  	<div class="container">
		  	<p class="left" style="color: white; font-size: 20px"><i class="material-icons small left prefix">lock_open</i>Open source</p>
				<img src="img/devdavi.png" class="tooltipped right" data-position="top" data-tooltip="Desenvolvedor">
			</div>
	  </div>
  </main>
</body>
</html>

<?php include 'components/js.php'; ?>